export const environment = {
  production: false,
  backendUrl: "https://paypal-tq3x.onrender.com"
};