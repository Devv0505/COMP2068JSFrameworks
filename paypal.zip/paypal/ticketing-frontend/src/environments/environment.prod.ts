export const environment = {
  production: true,
  backendUrl: "https://paypal-tq3x.onrender.com"
};